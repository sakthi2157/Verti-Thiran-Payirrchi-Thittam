# Security notes

- Keep `.env` out of version control.
- Change `SECRET_KEY` and `ADMIN_PASSWORD` before deployment.
- Set `secure=True` on the access-token cookie when serving over HTTPS.
- Put the app behind HTTPS and a reverse proxy in production.
- The app intentionally does not scrape marketplaces or claim live product availability.
- User-uploaded outfit images are stored locally only for the generated request and should be cleaned/retention-limited for production.
- For production, add CSRF protection for cookie-authenticated state-changing routes and a real migration system such as Alembic.
