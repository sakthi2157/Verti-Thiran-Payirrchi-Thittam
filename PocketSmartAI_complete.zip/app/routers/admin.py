from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..auth import get_current_admin
from ..config import get_settings
from ..database import get_db
from ..models import RecommendationHistory, User
from ..services.gemini_service import GEMINI

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/overview")
def overview(user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    return {
        "users": db.scalar(select(func.count(User.id))) or 0,
        "recommendations": db.scalar(select(func.count(RecommendationHistory.id))) or 0,
        "gemini_enabled": GEMINI.enabled,
        "model": get_settings().gemini_model,
    }
