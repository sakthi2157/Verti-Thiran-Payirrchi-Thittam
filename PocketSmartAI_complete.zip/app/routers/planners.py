from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session
from ..auth import get_current_user
from ..database import get_db
from ..models import RecommendationHistory, User
from ..schemas import HomeRequest, PartyRequest, JewelryRequest
from ..services.planner_service import generate
from ..config import get_settings

router = APIRouter(prefix="/api", tags=["planners"])
UPLOAD_DIR = Path(__file__).resolve().parent.parent / "static" / "uploads"
settings = get_settings()


def save_history(db: Session, user: User, planner: str, query: dict, result: dict):
    row = RecommendationHistory(user_id=user.id, planner=planner, query=query, result=result)
    db.add(row)
    db.commit()
    db.refresh(row)
    result["history_id"] = row.id
    return result


@router.post("/generate-home")
def generate_home(payload: HomeRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = payload.model_dump()
    return save_history(db, user, "home", data, generate("home", data))


@router.post("/generate-party")
def generate_party(payload: PartyRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = payload.model_dump()
    return save_history(db, user, "party", data, generate("party", data))


@router.post("/generate-jewelry")
async def generate_jewelry(
    budget: float = Form(..., gt=0),
    occasion: str = Form(...),
    style: str = Form("elegant"),
    outfit_color: str = Form("not specified"),
    requirements: str = Form(""),
    outfit_image: UploadFile | None = File(default=None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    payload = JewelryRequest(budget=budget, occasion=occasion, style=style, outfit_color=outfit_color, requirements=requirements)
    image_path = None
    if outfit_image and outfit_image.filename:
        if outfit_image.content_type not in {"image/jpeg", "image/png", "image/webp"}:
            raise HTTPException(400, "Only JPG, PNG, and WEBP images are supported")
        content = await outfit_image.read()
        if len(content) > settings.max_upload_mb * 1024 * 1024:
            raise HTTPException(413, "Image is too large")
        suffix = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}[outfit_image.content_type]
        image_path = UPLOAD_DIR / f"{uuid4().hex}{suffix}"
        image_path.write_bytes(content)
    data = payload.model_dump()
    result = generate("jewelry", data, image_path)
    return save_history(db, user, "jewelry", {**data, "image_uploaded": bool(image_path)}, result)


@router.get("/recommendations-details/{history_id}")
def recommendation_details(history_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.get(RecommendationHistory, history_id)
    if not row or row.user_id != user.id:
        raise HTTPException(404, "Recommendation not found")
    return {"id": row.id, "planner": row.planner, "query": row.query, "result": row.result, "created_at": row.created_at}
