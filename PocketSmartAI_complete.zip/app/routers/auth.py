from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..auth import create_access_token, get_current_user, hash_password, verify_password
from ..database import get_db
from ..models import User
from ..schemas import LoginRequest, RegisterRequest
from ..config import get_settings

router = APIRouter(prefix="/api", tags=["auth"])


@router.post("/register")
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if db.scalar(select(User).where(User.email == payload.email)):
        raise HTTPException(409, "An account with that email already exists")
    user = User(email=payload.email, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message": "Registration successful", "user": {"id": user.id, "email": user.email}}


@router.post("/login")
def login(payload: LoginRequest, response: Response, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    token = create_access_token(user)
    response.set_cookie("access_token", token, httponly=True, samesite="lax", secure=False, max_age=8 * 3600)
    return {"message": "Login successful", "user": {"id": user.id, "email": user.email, "is_admin": user.is_admin}, "access_token": token}


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("access_token")
    return {"message": "Logged out"}


@router.post("/token")
def token(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid credentials")
    return {"access_token": create_access_token(user), "token_type": "bearer"}


@router.get("/session-info")
def session_info(user: User = Depends(get_current_user)):
    return {"logged_in": True, "user_id": user.id, "email": user.email, "is_admin": user.is_admin}


@router.get("/session-data")
def session_data(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from ..models import RecommendationHistory
    count = db.query(RecommendationHistory).filter(RecommendationHistory.user_id == user.id).count()
    return {"user": {"id": user.id, "email": user.email}, "recommendation_count": count}


def seed_admin(db: Session):
    settings = get_settings()
    user = db.scalar(select(User).where(User.email == settings.admin_email.lower()))
    if not user:
        db.add(User(email=settings.admin_email.lower(), password_hash=hash_password(settings.admin_password), is_admin=True))
        db.commit()
    elif not user.is_admin:
        user.is_admin = True
        db.commit()
