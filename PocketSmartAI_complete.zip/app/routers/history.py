from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..auth import get_current_user
from ..database import get_db
from ..models import RecommendationHistory, User

router = APIRouter(prefix="/api", tags=["history"])


@router.get("/history")
def history(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(RecommendationHistory).where(RecommendationHistory.user_id == user.id).order_by(RecommendationHistory.created_at.desc()).limit(50)).all()
    return [{"id": r.id, "planner": r.planner, "query": r.query, "result": r.result, "created_at": r.created_at} for r in rows]
