from typing import Any, Literal
from pydantic import BaseModel, Field, field_validator

Planner = Literal["home", "party", "jewelry"]


class RegisterRequest(BaseModel):
    email: str = Field(min_length=5, max_length=255)
    password: str = Field(min_length=8, max_length=128)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        value = value.strip().lower()
        if "@" not in value or "." not in value.split("@")[-1]:
            raise ValueError("Enter a valid email address")
        return value


class LoginRequest(RegisterRequest):
    pass


class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=100_000_000)
    rooms: list[str] = Field(min_length=1)
    style: str = Field(default="modern", min_length=2, max_length=100)
    requirements: str = Field(default="", max_length=1000)


class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=100_000_000)
    guests: int = Field(gt=0, le=100_000)
    event_type: str = Field(min_length=2, max_length=100)
    venue: str = Field(default="home", max_length=200)
    requirements: str = Field(default="", max_length=1000)


class JewelryRequest(BaseModel):
    budget: float = Field(gt=0, le=100_000_000)
    occasion: str = Field(min_length=2, max_length=100)
    style: str = Field(default="elegant", min_length=2, max_length=100)
    outfit_color: str = Field(default="not specified", max_length=100)
    requirements: str = Field(default="", max_length=1000)


class RecommendationResponse(BaseModel):
    planner: Planner
    budget: float
    allocation: dict[str, float]
    recommendations: list[dict[str, Any]]
    notes: list[str] = []
    ai_generated: bool
    history_id: int | None = None
