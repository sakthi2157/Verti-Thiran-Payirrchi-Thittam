from pathlib import Path
from typing import Any
from .gemini_service import GeminiService
from .recommendations import fallback_home, fallback_party, fallback_jewelry

GEMINI = GeminiService()


def generate(planner: str, data: dict[str, Any], image_path: Path | None = None) -> dict:
    image_bytes = image_path.read_bytes() if image_path else None
    mime_type = None
    if image_path:
        suffix = image_path.suffix.lower()
        mime_type = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}.get(suffix)
    try:
        return GEMINI.generate(planner, data, image_bytes, mime_type)
    except Exception:
        if planner == "home":
            return fallback_home(data)
        if planner == "party":
            return fallback_party(data)
        return fallback_jewelry(data)
