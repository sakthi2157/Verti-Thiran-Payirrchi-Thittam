from urllib.parse import quote_plus

PLATFORMS = {
    "Amazon": "https://www.amazon.in/s?k={q}",
    "Flipkart": "https://www.flipkart.com/search?q={q}",
    "IKEA": "https://www.ikea.com/in/en/search/?q={q}",
    "Swiggy": "https://www.swiggy.com/search?query={q}",
    "Zomato": "https://www.zomato.com/search?q={q}",
    "OYO": "https://www.oyorooms.com/search?location={q}",
}


def search_url(platform: str, query: str) -> str:
    template = PLATFORMS.get(platform, "https://www.google.com/search?q={q}")
    return template.format(q=quote_plus(query))


def allocation_for(planner: str, budget: float) -> dict[str, float]:
    ratios = {
        "home": {"furniture": .40, "lighting": .15, "decor": .20, "storage": .15, "buffer": .10},
        "party": {"food": .45, "decoration": .20, "venue": .20, "entertainment": .10, "buffer": .05},
        "jewelry": {"necklace": .35, "earrings": .25, "bracelet": .20, "ring": .15, "buffer": .05},
    }[planner]
    return {key: round(budget * ratio, 2) for key, ratio in ratios.items()}


def fallback_home(data: dict) -> dict:
    budget = data["budget"]
    allocation = allocation_for("home", budget)
    rooms = ", ".join(data["rooms"])
    style = data["style"]
    items = [
        ("Living-room lighting set", allocation["lighting"], "Amazon", f"{style} LED ceiling and floor lighting"),
        ("Compact furniture bundle", allocation["furniture"], "IKEA", f"{style} compact furniture"),
        ("Wall decor set", allocation["decor"], "Flipkart", f"{style} wall decor"),
        ("Storage solution", allocation["storage"], "Amazon", f"{style} storage cabinet"),
    ]
    return _pack("home", budget, allocation, items, [f"Rooms: {rooms}", "Prices are planning estimates, not live quotes."])


def fallback_party(data: dict) -> dict:
    budget = data["budget"]
    allocation = allocation_for("party", budget)
    event = data["event_type"]
    guests = data["guests"]
    items = [
        (f"Catering plan for {guests} guests", allocation["food"], "Swiggy", f"{event} catering"),
        ("Decoration package", allocation["decoration"], "Amazon", f"{event} decoration"),
        ("Venue options", allocation["venue"], "OYO", f"{data['venue']} {event} venue"),
        ("Entertainment ideas", allocation["entertainment"], "Google", f"{event} entertainment"),
    ]
    return _pack("party", budget, allocation, items, [f"Event: {event}; guests: {guests}", "Use vendor quotes to confirm final pricing."])


def fallback_jewelry(data: dict) -> dict:
    budget = data["budget"]
    allocation = allocation_for("jewelry", budget)
    query_base = f"{data['style']} jewelry {data['occasion']} {data['outfit_color']}"
    items = [
        ("Statement necklace", allocation["necklace"], "Amazon", query_base + " necklace"),
        ("Matching earrings", allocation["earrings"], "Flipkart", query_base + " earrings"),
        ("Bracelet", allocation["bracelet"], "Amazon", query_base + " bracelet"),
        ("Minimal ring", allocation["ring"], "Flipkart", query_base + " ring"),
    ]
    return _pack("jewelry", budget, allocation, items, [f"Occasion: {data['occasion']}; outfit color: {data['outfit_color']}", "Image analysis is used only when Gemini is enabled."])


def _pack(planner, budget, allocation, items, notes):
    return {
        "planner": planner,
        "budget": budget,
        "allocation": allocation,
        "recommendations": [
            {"title": title, "estimated_budget": round(amount, 2), "platform": platform, "search_url": search_url(platform, query), "reason": "Fits the planner budget allocation and selected preferences."}
            for title, amount, platform, query in items
        ],
        "notes": notes,
        "ai_generated": False,
    }
