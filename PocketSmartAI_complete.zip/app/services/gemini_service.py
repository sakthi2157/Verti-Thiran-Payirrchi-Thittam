import json
from typing import Any
from google import genai
from google.genai import types
from .recommendations import allocation_for
from ..config import get_settings

settings = get_settings()


class GeminiService:
    def __init__(self):
        self.client = genai.Client(api_key=settings.gemini_api_key) if settings.gemini_api_key else None

    @property
    def enabled(self) -> bool:
        return bool(settings.ai_enabled and self.client and settings.gemini_api_key)

    def generate(self, planner: str, data: dict[str, Any], image_bytes: bytes | None = None, mime_type: str | None = None) -> dict:
        if not self.enabled:
            raise RuntimeError("Gemini is not configured")
        prompt = self._prompt(planner, data)
        contents: list[Any] = [prompt]
        if image_bytes and mime_type:
            contents.append(types.Part.from_bytes(data=image_bytes, mime_type=mime_type))
            contents.append("Use the outfit image only for broad color/style coordination; do not identify the person.")
        response = self.client.models.generate_content(model=settings.gemini_model, contents=contents)
        text = (response.text or "").strip()
        parsed = self._parse_json(text)
        if not parsed:
            raise RuntimeError("Gemini returned an unusable response")
        parsed.setdefault("planner", planner)
        parsed.setdefault("budget", data["budget"])
        parsed.setdefault("allocation", allocation_for(planner, data["budget"]))
        parsed.setdefault("recommendations", [])
        parsed.setdefault("notes", [])
        parsed["ai_generated"] = True
        return self._normalize(parsed, planner, data)

    def _prompt(self, planner: str, data: dict[str, Any]) -> str:
        return f"""You are PocketSmart AI, a budget planning assistant.\nPlanner: {planner}\nUser data: {json.dumps(data, ensure_ascii=False)}\n\nReturn ONLY valid JSON with this shape:\n{{\"planner\": \"{planner}\", \"budget\": number, \"allocation\": {{string: number}}, \"recommendations\": [{{\"title\": string, \"estimated_budget\": number, \"platform\": string, \"reason\": string, \"search_query\": string}}], \"notes\": [string]}}\n\nRules: keep the total estimated recommendation amounts within the user's budget; use only these platform names when relevant: Amazon, Flipkart, IKEA, Swiggy, Zomato, OYO; never claim live inventory or exact current price; use estimated ranges/amounts; give 4-8 useful recommendations; explain tradeoffs briefly.\n"""

    @staticmethod
    def _parse_json(text: str) -> dict | None:
        if not text:
            return None
        text = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        try:
            value = json.loads(text)
            return value if isinstance(value, dict) else None
        except json.JSONDecodeError:
            start, end = text.find("{"), text.rfind("}")
            if start >= 0 and end > start:
                try:
                    value = json.loads(text[start:end + 1])
                    return value if isinstance(value, dict) else None
                except json.JSONDecodeError:
                    return None
        return None

    @staticmethod
    def _normalize(result: dict, planner: str, data: dict) -> dict:
        allowed = {"Amazon", "Flipkart", "IKEA", "Swiggy", "Zomato", "OYO"}
        clean = []
        for item in result.get("recommendations", []):
            if not isinstance(item, dict):
                continue
            platform = item.get("platform", "Amazon")
            if platform not in allowed:
                platform = "Amazon"
            query = item.get("search_query") or item.get("title", "product")
            clean.append({
                "title": str(item.get("title", "Recommendation"))[:160],
                "estimated_budget": max(0.0, float(item.get("estimated_budget", 0) or 0)),
                "platform": platform,
                "reason": str(item.get("reason", "Budget-aware recommendation."))[:500],
                "search_url": __import__("app.services.recommendations", fromlist=["search_url"]).search_url(platform, query),
            })
        result["recommendations"] = clean[:8]
        result["budget"] = float(data["budget"])
        return result
