from app.services.recommendations import allocation_for, fallback_home, fallback_party, fallback_jewelry


def test_allocations_sum_to_budget():
    for planner in ('home', 'party', 'jewelry'):
        allocation = allocation_for(planner, 10000)
        assert round(sum(allocation.values()), 2) == 10000


def test_fallback_links_are_search_links():
    for fn, data in [
        (fallback_home, {'budget': 10000, 'rooms': ['Bedroom'], 'style': 'Modern', 'requirements': ''}),
        (fallback_party, {'budget': 10000, 'guests': 20, 'event_type': 'Birthday', 'venue': 'Home', 'requirements': ''}),
        (fallback_jewelry, {'budget': 10000, 'occasion': 'Party', 'style': 'Elegant', 'outfit_color': 'blue', 'requirements': ''}),
    ]:
        result = fn(data)
        assert result['recommendations']
        assert all('search_url' in x for x in result['recommendations'])
