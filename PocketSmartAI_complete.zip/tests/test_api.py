def register_and_login(client, email="user@example.com"):
    r = client.post('/api/register', json={'email': email, 'password': 'Password123!'})
    assert r.status_code == 200
    r = client.post('/api/login', json={'email': email, 'password': 'Password123!'})
    assert r.status_code == 200


def test_health(client):
    assert client.get('/health').json()['status'] == 'ok'


def test_home_planner_fallback_and_history(client):
    register_and_login(client)
    r = client.post('/api/generate-home', json={
        'budget': 100000, 'rooms': ['Living Room', 'Bedroom'], 'style': 'Modern', 'requirements': 'storage'
    })
    assert r.status_code == 200
    body = r.json()
    assert body['planner'] == 'home'
    assert body['ai_generated'] is False
    assert body['history_id'] is not None
    assert len(body['recommendations']) >= 3
    h = client.get('/api/history')
    assert h.status_code == 200
    assert len(h.json()) == 1


def test_party_planner(client):
    register_and_login(client)
    r = client.post('/api/generate-party', json={
        'budget': 50000, 'guests': 40, 'event_type': 'Birthday', 'venue': 'Home', 'requirements': ''
    })
    assert r.status_code == 200
    assert r.json()['allocation']['food'] == 22500


def test_jewelry_planner(client):
    register_and_login(client)
    r = client.post('/api/generate-jewelry', data={
        'budget': '15000', 'occasion': 'Wedding', 'style': 'Elegant', 'outfit_color': 'navy blue', 'requirements': ''
    })
    assert r.status_code == 200
    assert r.json()['planner'] == 'jewelry'


def test_token_endpoint(client):
    register_and_login(client, 'token@example.com')
    r = client.post('/api/token', json={'email': 'token@example.com', 'password': 'Password123!'})
    assert r.status_code == 200
    assert r.json()['token_type'] == 'bearer'
