@echo off
setlocal
if not exist .venv\Scripts\python.exe (
  py -m venv .venv
  .venv\Scripts\python.exe -m pip install --upgrade pip
  .venv\Scripts\python.exe -m pip install -r requirements.txt
)
if not exist .env copy .env.example .env
.venv\Scripts\python.exe -m uvicorn app.main:app --reload
