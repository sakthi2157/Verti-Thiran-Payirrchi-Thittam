# PocketSmart AI

A complete FastAPI + Jinja2 + SQLite application based on the supplied PocketSmart AI project documentation. It provides:

- Home Interior Budget Planner
- Party Budget Planner
- Jewelry Budget Planner with optional outfit image analysis
- Gemini multimodal AI integration
- Safe deterministic fallback recommendations when Gemini is unavailable
- User registration/login/logout and JWT token endpoint
- Session information and session data endpoints
- Recommendation history
- Recommendation details endpoint
- Admin health/configuration view
- Responsive browser UI
- Automated API/service tests

## Architecture

```text
Browser (Jinja2 + CSS + JS)
          |
          v
      FastAPI
   /auth /planner /history /admin
          |
     Services layer
      |         |
   SQLite     Gemini API
      |         |
      +--- Recommendation normalization
```

The original documentation references both Flask and FastAPI. This implementation follows the later FastAPI milestone because it explicitly defines the backend as FastAPI and specifies the routes and Jinja2 frontend. See the supplied project document, especially the FastAPI milestone and UI sections.

## Gemini model

The documentation names Gemini 1.5 Flash Pro. The application therefore exposes `GEMINI_MODEL` rather than hard-coding a retired model name. The example uses `gemini-2.5-flash`; change it in `.env` to any currently enabled Gemini model in your Google AI account.

## Important product-data behavior

The supplied document asks for Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO-style sourcing but also explicitly allows mock/simulated APIs. This implementation does **not** scrape or pretend to have live prices. AI recommendations include platform search links, while the fallback catalog uses clearly labeled sample estimates.

## Quick start (Windows PowerShell)

```powershell
cd PocketSmartAI
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set `GEMINI_API_KEY` if you want live AI. The app still runs without a key using deterministic fallback recommendations.

Start:

```powershell
uvicorn app.main:app --reload
```

Open: http://127.0.0.1:8000

## Quick start (macOS/Linux)

```bash
cd PocketSmartAI
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Testing

```bash
pytest -q
```

The test suite uses the fallback AI path and does not require a Gemini key.

## Admin

On first startup, the configured admin account is created from `ADMIN_EMAIL` and `ADMIN_PASSWORD`. Use the same login page, then visit `/admin`. For real deployment, change the default password and secret key.

The application itself does not require Windows Administrator privileges. If Windows reports a permission error while installing packages, open VS Code as Administrator or use a virtual environment in a writable folder.

## API routes

Authentication:
- `POST /api/register`
- `POST /api/login`
- `POST /api/logout`
- `POST /api/token`
- `GET /api/session-info`
- `GET /api/session-data`

Planners:
- `POST /api/generate-home`
- `POST /api/generate-party`
- `POST /api/generate-jewelry`
- `GET /api/recommendations-details/{history_id}`
- `GET /api/history`

Admin:
- `GET /api/admin/overview`

System:
- `GET /health`
- `GET /startup`
- Swagger UI: `/docs`

## Windows Administrator note

The application does not need Administrator privileges. Prefer a normal VS Code terminal. If your Windows machine blocks Python installation or port binding because of local permissions, you can start VS Code with **Run as administrator**, but do not put secrets in source files.

## Production note

This is a complete educational/development implementation. Before public deployment, add HTTPS, secure cookies, CSRF protection for cookie-authenticated mutations, rate limiting, database migrations, object storage/retention policy for uploads, and real marketplace/vendor APIs where permitted.
